import streamlit as st
import torch
import os
# Terminal: streamlit run net.py

prompt = st.chat_input("Say something")
img=st.file_uploader('image')


if prompt and img:
    with st.chat_message('ai'):
        ext=os.path.splitext(img.name)[1]
        st.line_chart(torch.randn(10,50))
        st.write(f"User has sent the following prompt: {prompt}")
        if ext in ['.jpeg','.jpg','.png']:
            st.image(img)

elif prompt:
    with st.chat_message('ai'):
        st.write(f"User has sent the following prompt: {prompt}")
        st.bar_chart(torch.randn(10,50))
   
elif img:
    with st.chat_message('ai'):
        st.write(os.path.splitext(img.name)[1])
        # st.image(img)
        st.scatter_chart(torch.randn(10,50))
        
     
